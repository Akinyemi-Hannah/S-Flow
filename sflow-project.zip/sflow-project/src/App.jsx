import SFlow from './SFlow.jsx'

export default function App() {
  return <SFlow />
}
